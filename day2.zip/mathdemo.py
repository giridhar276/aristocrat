
# importing all the methods
import math
print(math.floor(45.4))
print(math.ceil(45.4))

# importing using alias name
import math as m
print(m.floor(45.4))
print(m.ceil(45.4))

## importing the methods directly
from math import log
print(log(2))



from datetime import datetime
print(datetime.now())