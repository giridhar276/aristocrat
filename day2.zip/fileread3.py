



import csv
cityset = set()
with open("realestate.csv","r") as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        if "SACRAMENTO" in line:
            print(line)



import csv
cityset = set()
with open("realestate.csv","r") as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        if "SACRAMENTO" in line:
            line[1] = "HYDERABAD"
        print(line)
