



fixed = "192.168.0."

for val in range(1,11):
    print(fixed + str(val))