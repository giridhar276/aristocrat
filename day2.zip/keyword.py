

# keyword arguments

def display(a,b):
    print(first,second)




display(second=20,first=10)


print(10,20,end="\n\n",sep="*")