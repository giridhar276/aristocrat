alist = ["google","oracle","microsoft"]

for item in alist:
    print("http://www." + item + ".com")