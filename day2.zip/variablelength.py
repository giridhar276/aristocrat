

# variable length


def display(*data):

    for val in data:
        print(val)

display(10,20,30,40,50,60,70,80,4,4)




def newdisplay(**info):
    for key,value in info.items():
        print(key,value)

newdisplay(chap1=10,chap2=20,chap3=30)
