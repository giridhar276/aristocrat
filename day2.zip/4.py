import csv
citylist = list()
with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    #converting file object to csv object
    reader = csv.reader(fobj)
    ## processing the data
    for line in reader:
        citylist.append(line[1])
    
    ## displaying the output
    for city in set(citylist):
        print(city.ljust(15), citylist.count(city))



import csv
myCityDict = dict()
with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        city = line[1]
        if city in myCityDict.keys(): 
            myCityDict[city] = myCityDict[city] +1
        else:
            myCityDict[city]=1


    
    ## displaying the output
    for key,value in myCityDict.items():
        print(key,value)