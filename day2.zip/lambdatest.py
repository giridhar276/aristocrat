


def display(a,b):
    c = a + b
    return c

total = display(10,20)
print(total)



# lambda
# syntax:
#functionname = lambda variables : expression
display = lambda x,y : x + y

total = display(10,20)
print(total)





getdata = lambda name : name.upper()
output = getdata("python")
print(output)



alist = ["google","oracle","microsoft","unix","ruby","rexx"]

print(list(map(lambda domain : "www." + domain + ".com" ,alist)))


print(tuple(filter(lambda domain: len(domain) == 4 , alist)))




# syntax:    map(lambdafunction,iterable)
#           filter(function,iterable)

numbers = [1,2,3,4,4,5,6]
print(list(filter(lambda x: x%2 , numbers)))








