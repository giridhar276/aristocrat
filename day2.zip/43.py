infodoc = { 2001: {"ap":76} , 2002:{"tn":75} , 2003:{"up":90} }



print("state".ljust(10), "literacy rate")
for value in infodoc.values():
    key = list(value.keys())
    value = list(value.values())
    print(key[0].ljust(10),str(value[0]).ljust(10))