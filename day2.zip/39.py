domains = ["google","www.unix","oracle.com"]

for item in domains:
    if not item.startswith("www"):
        item = "www." + item
    if not item.endswith(".com"):
        item = item + ".com"
    print(item)