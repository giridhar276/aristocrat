import csv
import sys
citylist = list()

try:
    with open("realestate.csv","r") as fobj:
        header = fobj.readline()
        #converting file object to csv object
        reader = csv.reader(fobj)
        ## processing the data
        for line in reader:
            citylist.append(line[1])
        
        ## displaying the output
        for city in set(citylist):
            print(city.ljust(15), citylist.count(city))

except FileNotFoundError as error:
    pass

    
