# default  arguments

# function overloading
def display(a=0,b=0,c=0):
    print(a,b,c)


    


display()
display(10)
display(10,20)
display(10,20,30)


print(10,20,sep="*")

print(list(range(2,10,2)))


