




import csv
cityset = set()
with open("realestate.csv","r") as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line[1])



import csv
cityset = set()
with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    #converting file object to csv object
    reader = csv.reader(fobj)
    ## processing the data
    for line in reader:
        cityset.add(line[1])
    
    ## displaying the output
    for city in cityset:
        print(city)



import csv
citydict = dict()
with open("realestate.csv","r") as fobj:
    # reading header and ignoring it
    header = fobj.readline()
    #converting file object to csv object
    reader = csv.reader(fobj)
    ## processing the data
    for line in reader:
        city = line[1]
        # trying to convert each city as the key
        citydict[city] = 1
    
    ## displaying the output
    for city in citydict:
        print(city)











