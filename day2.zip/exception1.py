# fobj is called as file handler or cursor or file object
with open("languages.txt","r") as fobj:
    for line in fobj:
        # remove whitespaces if any
        line = line.strip()
        output = line.split(",")
        print(output)
        
        
## using fobj.readlines()
# fobj is called as file handler or cursor or file object
with open("languages.txt","r") as fobj:
    print(fobj.readlines())
    

#with open("D:\\test\\newtest\\languages.txt","r") as fobj:    
#with open("D:/test/newtest/languages.txt","r") as fobj:    
#with open(r"D:\test\newtest\languages.txt","r") as fobj:    

    
# using fobj.read()
with open("D:\\test\\newtest\\languages.txt","r") as fobj:
    print(fobj.read())
    
    
import csv
with open("languages.txt","r") as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)