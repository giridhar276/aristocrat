

import pymysql


#step1
db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123',database='aristocrat')
if db:
    cursor = db.cursor()
    #step2
    query = "select * from realestate"
    # step3
    cursor.execute(query)
    #step4
    for record in cursor.fetchall():
        print("Street:",record[0])
        print("City  :",record[1])
        print("-------------")
#step5
db.close()