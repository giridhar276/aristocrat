
class Student:
    def getname(self):
        print("this is getname()")
    def getroll(self):
        print("this is getroll()")
        
        
student1 = Student()
student1.getname()
student1.getroll()



class Student:
    def getname(self,name):
        self.name = name
        print("Name :",self.name)
    def displayName(self):
        print("Yes... name is ",self.name)

        
student1 = Student()
student1.getname("Patel")
student1.displayName()


# with constructor
class Student:
    def __init__(self,val=0,name=0):
        self.val = val
        self.name = name
    def displayName(self):
        print("Name :", self.name)
        
#constructor is used for initializing the values
#Constructor is invoked automatically when the class is initialized

if __name__ == "__main__":
    student1 = Student(101,'Ram')
    student1.displayName()














