

import pymysql

try:
    #step1 - establish the connection
    db = pymysql.connect(host='12.3.3.3',port=3306,user='root',password='india@123',database='aristocrat')
    if db:
        # cursor - cursor is the 
        cursor = db.cursor()
        #step2
        query = "insert into realestate values('{}','{}')".format('Gandhinagar','Noida')
        # step3
        cursor.execute(query)
        #step4 - make the changes permanent
        db.commit()
    #step5
    db.close()
except Exception as err:
    print(err)



## task : write a program to read the realestate.csv and insert street and city
#                                      to the database
