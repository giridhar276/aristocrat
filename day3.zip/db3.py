

import pymysql
import csv
try:
    #step1 - establish the connection    
    db = pymysql.connect(host='localhost',port=3306,user='root',password='india@123')    
    with open("realestate.csv","r") as fobj:
        header = fobj.readline()

        csvreader = csv.reader(fobj)
        for line in csvreader:
            street = line[0]
            city = line[1]   
            # cursor - cursor is the 
            cursor = db.cursor()
            #step2
            query = "insert into aristocrat.realestate values('{}','{}')".format(street,city)
            # step3
            cursor.execute(query)
            #step4 - make the changes permanent
    db.commit()
    #step5
    db.close()
except pymysql.OperationalError as err:
    print(err)
except pymysql. DataError as err:
    print(err)
except (TypeError,ValueError ) as err:
    print(err)
except Exception as err:
    print(err)

 
