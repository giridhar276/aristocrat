

from openpyxl import Workbook
import csv
import os
import time
import sys
import time

try:
    outputfile = time.strftime("%d_%b_%Y_%H.xlsx")
    filename = "realestate.csv"
    wb = Workbook()
    # grab the active worksheet
    ws = wb.active

    if os.path.exists(filename) and os.path.isfile(filename):
        with open(filename,"r") as fobj:
            csvreader = csv.reader(fobj)
            for line in csvreader:
                # Rows can also be appended
                ws.append(line)
        
    else:
        print("Input file doesn't exist")
        sys.exit(0)

    # Save the file
    wb.save(outputfile)
except Exception as err:
    print(err)