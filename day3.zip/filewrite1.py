

fobj = open("customers.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")
fobj.close()



# context manager
# file will be closed automatically
with open("customers.txt","w") as fobj:
    fobj.write("python programming\n")
    fobj.write("scala programming\n")


    