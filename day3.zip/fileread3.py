




import csv

def main():
    cityset = set()
    with open("realestate.csv","r") as fobj:
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            if "SACRAMENTO" in line:
                line[1] = "HYDERABAD"
            print(line)
    


if __name__ == "__main__":
    main()
