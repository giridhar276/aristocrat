import configparser
parser  = configparser.ConfigParser()
parser.read('credentials.conf')
print(parser.sections())


url = parser.get('restapi', 'url')
username = parser.get('restapi','username')
dbuser = parser.get('database','user')
password = parser.get('database','password')
port = parser.get('database','port')
print("server :",url)
print("username :",username)
print("Database user :", dbuser)
print(password)
print(port)

