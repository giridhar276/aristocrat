
book = {"chap1":10 ,"chap2":20 ,"chap3":30 , "chap1":1000}



print(book["chap1"])
print(book["chap2"])
print(book["chap3"])
#print(book["chap4"])