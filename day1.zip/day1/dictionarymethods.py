

book = {"chap1":10 ,"chap2":20 ,"chap3":30 , "chap1":1000}

print("ONLY keys:", book.keys())

for key in book.keys():
    print(key)
  
    
print("ONLY values:", book.values())

for value in book.values():
    print(value)
    
    
print("DISPLAY ITEMS:",book.items())

for key,value in book.items():
    print(key,value)
    

print(book["chap1"])
print(book["chap5"])
print(book.get("chap9"))


val = 10+ 430
print(val)

final = "python" + " " + "programming"
print(final)

final = [10,20,30] + [40,50,60]
print(final)



book1 = {"chap1":10 ,"chap2":20 ,"chap3":30 }
book2 = {"chap4":40 , "chap5":50}

final = {**book1,**book2}
print(final)

book1.update(book2)
print(book1)






