


aset  = {10,20,30,10,10,10}
bset = {30,40,30,30,30,50}

print(aset)
print(bset)

print(aset.union(bset))
print(aset.intersection(bset))
print(aset.issubset(bset))
print(aset.difference(bset))

print(aset.issubset((bset)))

aset.add(10)
print(aset)
aset.add(100)
print(aset)
