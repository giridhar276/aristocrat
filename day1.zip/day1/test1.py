



alist = [10,10,10,10,10,20,30]
adict = dict()
for val in alist:
    adict[val] = 1
    
print(list(adict.keys()))