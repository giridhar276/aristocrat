



alist = [10,20,30,40,50,60]

getcount = alist.count(10)

if getcount > 0 :
    print("10 exists")
    
    


alist = [10,20,30,40,50,60]

if 10 in alist:
    print("exists")
    

string = "python programming"
getcount = string.count("program")

if "program" in string:
    print("exists")
    
    
    
adict = {"chap1":10 ,"chap2":20}

if "chap3" in adict:
    print("exists")
    
    
output = adict.get("chap3")
if output is None:
 print("does not exist")    
    
    

    
    
    