


name = "python programming"

print(name.count("p"))
print(name.count("z"))

print(name.count('m'))

print(name.upper()) # just displaying the output on screen
print(name)

print(name.lower())

if name.islower():
    print("Lower")
else:
    print("upper")

print(name.replace("python","ruby"))

## converted to the list
line = "perl,scala,hadoop,ML"
output = line.split(",")
print(output)

print(list(line))


print(len(name))
alist = [10,20,30]
print(len(alist))



aname = "  python "
print(len(aname))


print(aname.strip())
print(len(aname.strip()))

print(aname.lstrip())
print(len(aname.strip()))


# template|skeleton
lang = "testing"
name = "I love {} and {1} and {0} and {2}"
print(name.format("python","spark",lang))











