alist = [54,34,64,53,6453,3]


print(alist.index(34))


## passing single value
alist.append(34)
print("After appending:", alist)
alist.append(67)
print("After appending:", alist)

# passing multiple values in list format
alist.extend([45,67,89,90])
print("After extending :", alist)

# insert(position,value)
# insert(where to insert, what to insert)
alist.insert(0,10000)
print("After inserting:", alist)
alist.insert(3,102)
print("After inserting:", alist)

# default is last value
alist.pop()   
print("After pop:", alist)
# will remove the value based on index
alist.pop(0)
print("After pop:", alist)

alist.remove(64)  # will remove the value DIRECTLY or else throw an erro
print("After removing:",alist)

alist.sort()   # Default: ascending order
print("After sorting :", alist)

alist.sort(reverse = True)   # descending order
print("After sorting :", alist)



alist.reverse()
print("After reversing :",alist)




## converting list to list
alist = ["python","java"]
line = ",".join(alist)
print(line)

