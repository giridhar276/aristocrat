
name= "python programming"
print(name)


# string slicing
# string[start:stop:step]
print(name[0])  # p
print(name[1])  # y
print(name[0:5])
print(name[1:8])
print(name[:])
print(name[::])
print(name[5:9])
print(name[-1])
print(name[-2])
print(name[0::])
print(name[0:17:2])
print(name[1:17:2])
print(name[0:17:3])
print(name[-4:])
print(name[::-1])


