atup = (45,45,4)
btup = ("unix",56,5.5)


print("tuple values are", atup)

#atup[0] = 1000

#print("After replacing:", atup)


# converting tuple to list
alist =list(atup)
alist[0] = 45000
#recoverting back to tuple
atup = tuple(alist)
print("After replacing:", atup)