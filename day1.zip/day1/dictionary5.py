

book = {"chap1":10 ,"chap2":20 ,"chap3":30}

print(len(book))

# reading ONLy key and displaying  key and value
for key in book:
    print(key)
    print(book[key])
    

# at the reading itself, we are reading keys and values
for key,value in book.items():
    print(key,value)
    
