# for with range
for val in range(2,11,3):
    print(val)
    
    
# for loop with list
alist = [10,20,30,40,40]
for val in alist:
    print(val)
    
# for loop with tuple
atup = (12,23,34,45)
for val in atup:
    print(val,end=' ')

  

# for loop with string
name = "python programming"
for char in name:
    print(char)
    



