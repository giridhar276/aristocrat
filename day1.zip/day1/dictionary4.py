


data = {"menu": {
      "id": "file",
      "value": "File",
      "popup": {
        "menuitem": [
          {"value": "New", "onclick": "CreateNewDoc()"},
          {"value": "Open", "onclick": "OpenDoc()"},
          {"value": "Close", "onclick": "CloseDoc()"}
        ]
      }
    }}

print (data["menu"]["popup"]["menuitem"][0]['value'])
print (data["menu"]["popup"]["menuitem"][1]['value'])
print (data["menu"]["popup"]["menuitem"][2]['value'])
