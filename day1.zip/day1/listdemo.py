

alist = [10,20,30,40,50,60,70,80]
blist = ["unix","go","scala"]
clist = [20,3,4.5,"java"]


print(alist)

print(blist)

alist[0] = 1000

print("After replacing :", alist)

# list slicing
print(alist[0:5])
print(alist[::-1])