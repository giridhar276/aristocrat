



name = input("Enter any name:")
print("You entered :", name)